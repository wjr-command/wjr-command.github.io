import os
import sys
import webview

def create_browser():
    window = webview.create_window(
        'wjr的个人主页',
        'http://[2409:8a7a:1473:8120:a79:cb73:28f1:d918]',
        width=800,
        height=600,
        resizable=True,
    )
    webview.start()

if __name__ == '__main__':
    create_browser()